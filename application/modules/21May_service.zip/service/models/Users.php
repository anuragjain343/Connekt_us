<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//General service API class 
class Users extends CommonService{
    
    public function __construct(){
        parent::__construct();
        $this->load->model('Users_model'); //load user model
        $this->list_limit = 20;  //limit record
    }

    function getDropdownList_get(){

    	//check for auth
        $this->check_service_auth();
        
        $where = array('userType'=>$this->authData->userType);

        $result = $this->Users_model->getDropdown_data($where);
        $response = array('status' => SUCCESS, 'result'=>$result);
        $this->response($response);  
    }


    //validation callback for checking alpha_spaces
    function _alpha_spaces_check($string){
        if(alpha_spaces($string)){
            return true;
        }
        else{
            $this->form_validation->set_message('_alpha_spaces_check','Only alphabets and spaces are allowed in {field} field');
            return FALSE;
        }
    }


    //update or insert business profile here
    function updateBusinessProfile_post(){

         //check for auth
        $this->check_service_auth();
        

        $current_user_id = $this->authData->userId; 

        $this->form_validation->set_rules('area_of_specialization', 'Area of specialization', 'trim|required');
        $this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[2]|max_length[200]');
        //$this->form_validation->set_rules('bio', 'Bio', 'trim|required|min_length[2]|max_length[200]');
        $this->form_validation->set_rules('job_title', 'Job title', 'trim|required');


        //validation here
        
        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' => strip_tags(validation_errors()));
            $this->response($response); die;
        }

        if(empty($_FILES['company_logo']['name'])){
            $response = array('status' => FAIL, 'message' => 'Company logo is requried');
            $this->response($response); die;;
        }

        $company_logo = array();
        if(!empty($_FILES['company_logo']['name'])){
            
            $folder = 'company_logo';
            $this->load->model('Image_model');
            $company_logo = $this->Image_model->updateMedia('company_logo',$folder);

        }
        if(is_array($company_logo) && !empty($company_logo['error']))
        {
            $response = array('status' => FAIL, 'message' =>$company_logo['error']);
            $this->response($response);
        }


        $set = array('address', 'bio','latitude', 'longitude');
        foreach ($set as $key => $val) {
            $post= $this->post($val);
            if(!empty($post))
                $insert_data[$val] = $post;
        }

        if(is_string($company_logo) && !empty($company_logo)){

            $insert_data['company_logo']       = $company_logo;
        }
        
        elseif (filter_var($this->input->post('company_logo'), FILTER_VALIDATE_URL)) {
            $insert_data['company_logo'] = $this->input->post('company_logo');
        }
       
        $insert_data['user_id'] = $current_user_id;  // user id
        $insert_data['jobTitle_id'] = $this->post('job_title');
        $where  = array('user_id'=>$current_user_id);
      
        $is_exist = $this->common_model->is_data_exists(USER_META, $where);
        if($is_exist){
            $this->common_model->updateFields(USER_META, $insert_data,$where);
        }else{
            
            $meta_id = $this->common_model->insertData(USER_META, $insert_data);  //insert data
            if(!$meta_id){ 

                $response = array('status'=>FAIL, 'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            }
            $this->common_model->updateFields(USERS,array('isProfile'=>1),array('userId'=>$current_user_id));
        }
        
    
            
        $exist = $this->common_model->is_data_exists(USER_SPECIALIZATION_MAPPING, array('user_id'=>$current_user_id));
        $speciality_data = array('user_id'=>$current_user_id, 'specialization_id'=>$this->input->post('area_of_specialization'));
        if($exist){

            $this->common_model->updateFields(USER_SPECIALIZATION_MAPPING, $speciality_data,array('user_id'=>$current_user_id));
        }else{
            $speciality_id = $this->common_model->insertData(USER_SPECIALIZATION_MAPPING, $speciality_data);
            if(!$speciality_id){
                $response = array('status'=>FAIL, 'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            }
        }

        $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(125));
        $this->response($response);
    }


    //update or insert indivisual's basic info here
    function updateBasicInfo_post(){

         //check for auth
        $this->check_service_auth();

        $current_user_id = $this->authData->userId;

        $this->form_validation->set_rules('area_of_specialization', 'Area of specialization', 'trim|required');
        $this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[2]|max_length[200]');
        //$this->form_validation->set_rules('bio', 'Bio', 'trim|required|min_length[2]|max_length[200]');
        $this->form_validation->set_rules('value', 'value', 'trim|required');
        $this->form_validation->set_rules('strength', 'strength', 'trim|required');
       
        
        //validation here
        
        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' => preg_replace("/[\\n\\r]+/", " ",strip_tags(validation_errors())));
            $this->response($response); die;
        }


        $set = array('address', 'bio','latitude', 'longitude');
        foreach ($set as $key => $val) {
            $post= $this->post($val);
            if(!empty($post))
                $insert_data[$val] = $post;
        }

       
        $insert_data['user_id'] = $current_user_id;  // user id
        $where  = array('user_id'=>$current_user_id);
       
        $is_exist = $this->common_model->is_data_exists(USER_META, $where );
        if($is_exist){
            $this->common_model->updateData(USER_META, $insert_data,$where );
        }else{
            
            $meta_id = $this->common_model->insertData(USER_META, $insert_data);  //insert data
            if(!$meta_id){
                $response = array('status'=>FAIL, 'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            }
            $this->common_model->updateFields(USERS,array('isProfile'=>1),array('userId'=>$current_user_id));
        } 
       
        //check whether value empty or not, if not (delete all previous values and insert new)
        
        $this->common_model->deleteData(USER_VALUE_MAPPING,$where );

         //insert multiple values here
        foreach (explode(',', $this->post('value'))  as  $value) {

            $this->common_model->insertData(USER_VALUE_MAPPING, array('user_id'=>$current_user_id, 'value_id'=>$value));
       
        }
       
      
        //check whether strength empty or not, if not (delete all previous strength and insert new)
        $this->common_model->deleteData(USER_STRENGTH_MAPPING,$where);

        //insert multiple strengths here
        foreach (explode(',', $this->post('strength'))  as  $val) {
           
            $this->common_model->insertData(USER_STRENGTH_MAPPING,array('user_id'=>$current_user_id, 'strength_id'=>$val));
       
        }
        
        
        //check whether area_of_specialization empty or not, if not (delete all previous area_of_specialization and insert new)

        $this->common_model->deleteData(USER_SPECIALIZATION_MAPPING,$where);
        //insert area_of_specialization data
        $this->common_model->insertData(USER_SPECIALIZATION_MAPPING, array('user_id'=>$current_user_id, 'specialization_id'=>$this->post('area_of_specialization')));
       
    
        $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(125));
   
        $this->response($response);
    } //End function



    function updateResume_post(){

         //check for auth
        $this->check_service_auth();

        $current_user_id = $this->authData->userId;
        $resume = array();
        if(!empty($_FILES['resume']['name'])){
            
            $folder = 'user_resume';
            $this->load->model('Image_model');
            $resume = $this->Image_model->updateContent('resume',$folder);

        }
        if(is_array($resume) && !empty($resume['error']))
        {
            $response = array('status' => FAIL, 'message' =>$company_logo['error']);
            $this->response($response);
        }

        if(is_string($resume) && !empty($resume)){

            $insert_data['user_resume']       = $resume;
        }elseif (filter_var($this->input->post('resume'), FILTER_VALIDATE_URL)) {
            $insert_data['user_resume'] = $this->post('resume');
        }

        //upload user's cv here
        $cv = array();
        if(!empty($_FILES['cv']['name'])){
            
            $folder = 'user_cv';
            $this->load->model('Image_model');
            $cv = $this->Image_model->updateContent('cv',$folder);

        }
        if(is_array($cv) && !empty($cv['error']))
        {
            $response = array('status' => FAIL, 'message' =>$cv['error']);
            $this->response($response);
        }

        if(is_string($cv) && !empty($cv)){

            $insert_data['user_cv']       = $cv;
        }elseif (filter_var($this->input->post('cv'), FILTER_VALIDATE_URL)) {
            $insert_data['user_cv'] = $this->post('cv');
        }

        $where  = array('user_id'=>$current_user_id);
        $is_exist = $this->common_model->is_data_exists(USER_META, $where);
        if(!$is_exist){
            $response = array('status'=>FAIL, 'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            $this->response($response); 
        }

        if(!empty($insert_data )){

            $this->common_model->updateFields(USER_META, $insert_data,$where);
        }else{

            $response = array('status'=>FAIL, 'message'=>ResponseMessages::getStatusCodeMessage(142)); //fail- something went wrong
            $this->response($response); 
        }

        $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(143));
        $this->response($response);
         
    } //End function


    //update or insert user experience here
    function updateExperience_post(){

        //check for auth
        $this->check_service_auth();

        $current_user_id = $this->authData->userId;

        $set = array('current_job_title', 'current_company','current_start_date', 'current_finish_date', 'current_description','previous_role','next_availability','next_speciality','next_location');
        foreach ($set as $key => $val) {
            $post= trim($this->post($val));
            if(!empty($post))
                $exp_data[$val] = $post;
        }

        $where = array('user_id'=>$current_user_id);
        $exp_data['user_id'] = $current_user_id;  // user id
       
        $is_exist = $this->common_model->is_data_exists(USER_EXPERIENCE, $where );
        if($is_exist){
            $this->common_model->updateData(USER_EXPERIENCE, $exp_data,$where);
        }else{
            
            $exp_id = $this->common_model->insertData(USER_EXPERIENCE, $exp_data);  //insert data  
            if(!$exp_id){
                $response = array('status'=>FAIL, 'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
                $this->response($response); 
            }   
        } 

        $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(125));
        $this->response($response);
    } //End function


    function getUserProfile_get(){

        //check for auth
        $this->check_service_auth();

        $current_user_id = $this->authData->userId;
        $user_type = $this->authData->userType;
        if($user_type == 'business'){
            $business_data = $this->Users_model->get_business_user(array('um.user_id'=>$current_user_id));
            $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(125),'business_profile'=>$business_data);
            $this->response($response); 
        }
        $where = array('user_id'=>$current_user_id);
        $basic_info = $this->Users_model->get_indivisual_basic_info(array('um.user_id'=>$current_user_id));
        $experience = $this->Users_model->get_user_experience($where);
        $resume = $this->Users_model->get_user_resume($where);

        $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(126),'basic_info'=>$basic_info,'experience'=>$experience,'resume'=>$resume);
        $this->response($response); 
    
    } //End function


    //add review here
    function addReview_post(){

        //check for auth
        $this->check_service_auth();

        $current_user_id = $this->authData->userId;
        
        $this->form_validation->set_rules('rating', 'rating', 'trim|required|numeric');
        $this->form_validation->set_rules('comments', 'comment', 'trim|required|min_length[2]|max_length[200]');
        $this->form_validation->set_rules('review_for', 'Review', 'required', array('required'=>'Please select user to review for'));
        $this->form_validation->set_rules('is_anonymous', 'is_anonymous', 'trim|required');
        
        
        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' => spreg_replace("/[\\n\\r]+/", " ",strip_tags(validation_errors())));
            $this->response($response); 
        }
        
            $is_id_exist = $this->common_model->is_id_exist(USERS,'userId',$this->post('review_for'));
            if(!$is_id_exist){
                $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
                $this->response($response); 
            }

            $set = array('review_for', 'rating', 'comments','is_anonymous');
            foreach ($set as $key => $val) {
                $post= $this->post($val);
                if(!empty($post))
                    $insert_data[$val] = $post;
            }
            $insert_data['review_by'] = $current_user_id;
            $insert_data['created_on'] = datetime();
       
            $review_id = $this->common_model->insertData(REVIEWS, $insert_data);  //insert new post data
            if(!$review_id){
                $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
                $this->response($response); 
            }

            $review_for = $insert_data['review_for'];
            $review_data = $this->Users_model->get_user_reviews($review_for, 1, $offset=0); //get last inserted review data
    
            $response = array('status'=>SUCCESS,'message'=>ResponseMessages::getStatusCodeMessage(125), 'reviewDetail'=>$review_data);        
        
            $this->response($response);

    } //End function


    function addFavourites_post(){

        //check for auth
        $this->check_service_auth();

        $current_user_id = $this->authData->userId;
        
        
        $this->form_validation->set_rules('favourite_for', 'favourite', 'required', array('required'=>'Please select user to favourite'));
        
        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' => preg_replace("/[\\n\\r]+/", " ",strip_tags(validation_errors())));
            $this->response($response); 
        }

            $is_id_exist = $this->common_model->is_data_exists(USERS, array('userId'=>$this->post('favourite_for'),'status'=>1));
            if(!$is_id_exist){
                $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
                $this->response($response); 
            }
        
            $insert_data['favourite_for'] = $this->post('favourite_for') ;
            $insert_data['favourite_by'] = $current_user_id;
            $insert_data['created_on'] = datetime();
    
            $where = array('favourite_by'=>$current_user_id,'favourite_for'=>$insert_data['favourite_for']);
            //check if user added to favourites or not. if not, insert into favourites
            $is_exist = $this->common_model->is_data_exists(FAVOURITES,$where);
            if($is_exist){

                //remove from favourites if it already exist
                $this->common_model->deleteData(FAVOURITES,$where);
                $response = array('status'=>SUCCESS,'message'=>ResponseMessages::getStatusCodeMessage(138),'isFavourite'=>0);
                $this->response($response); 
            }
       
            $fav_id = $this->common_model->insertData(FAVOURITES, $insert_data);  //insert new  data
            if(!$fav_id){
                $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
                $this->response($response); 
            }
            $response = array('status'=>SUCCESS,'message'=>ResponseMessages::getStatusCodeMessage(129),'isFavourite'=>1);  
            $this->response($response);

    } //End function

    //recommend  user here
    function addRecommends_post(){

        //check for auth
        $this->check_service_auth();

        $current_user_id = $this->authData->userId;
        
        
        $this->form_validation->set_rules('recommend_for', 'recommend', 'required', array('required'=>'Please select user to recommend'));
        
        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' => preg_replace("/[\\n\\r]+/", " ",strip_tags(validation_errors())));
            $this->response($response); 
        }
        
            $is_id_exist = $this->common_model->is_data_exists(USERS, array('userId'=>$this->post('recommend_for'),'status'=>1));
            if(!$is_id_exist){
                $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
                $this->response($response); 
            }
        
            $insert_data['recommend_for'] = $this->post('recommend_for') ;
            $insert_data['recommend_by'] = $current_user_id;
            $insert_data['created_on'] = datetime();
    
            $where = array('recommend_by'=>$current_user_id,'recommend_for'=>$insert_data['recommend_for']);
            //check if user added to recommends or not. if not, insert into recommends
            $is_exist = $this->common_model->is_data_exists(RECOMMENDS,$where);
            if($is_exist){

                //remove from recommends if it already exist
                $this->common_model->deleteData(RECOMMENDS,$where);
                $response = array('status'=>SUCCESS,'message'=>ResponseMessages::getStatusCodeMessage(140),'isRecommend'=>0);
                $this->response($response); 
            }
       
            $rec_id = $this->common_model->insertData(RECOMMENDS, $insert_data);  //insert new  data
            if(!$rec_id){
                $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
                $this->response($response); 
            }
            $response = array('status'=>SUCCESS,'message'=>ResponseMessages::getStatusCodeMessage(139),'isRecommend'=>1);  
            $this->response($response);

    } //End function


    //get user reviews by user ID
    function getUserReviews_get(){

        //check for auth
        $this->check_service_auth();

        $offset = $this->get('offset'); $limit = $this->get('limit');
        if(empty($offset) || empty($limit)){
            $limit= $this->list_limit; $offset = 0;
        }
        $user_id = $this->get('user_id');

        $is_id_exist = $this->common_model->is_data_exists(USERS, array('userId'=>$user_id,'status'=>1));
        if(!$is_id_exist){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
            $this->response($response); 
        }

        $user_reviews = $this->Users_model->get_user_reviews_list($user_id, $limit, $offset, $check_status=true);
        $response = array('status' => SUCCESS, 'reviewList'=>$user_reviews); //success msg
        $this->response($response);

    } //End function


     //get user recommends by user ID
    function getUserRecommends_get(){

        //check for auth
        $this->check_service_auth();

        $offset = $this->get('offset'); $limit = $this->get('limit');
        if(empty($offset) || empty($limit)){
            $limit= $this->list_limit; $offset = 0;
        }
        $user_id = $this->get('user_id');
        $is_id_exist = $this->common_model->is_data_exists(USERS, array('userId'=>$user_id,'status'=>1));
        if(!$is_id_exist){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
            $this->response($response); 
        }
        $user_recommends = $this->Users_model->get_user_recommend_list($user_id, $limit, $offset, $check_status=true);
        $response = array('status' => SUCCESS, 'recommendList'=>$user_recommends); //success msg
        $this->response($response);

    } //End function


    //get user favourites by user ID
    function getUserFavourites_get(){

        //check for auth
        $this->check_service_auth();

        $offset = $this->get('offset'); $limit = $this->get('limit');
        if(empty($offset) || empty($limit)){
            $limit= $this->list_limit; $offset = 0;
        }
        $user_id = $this->get('user_id');
        $is_id_exist = $this->common_model->is_data_exists(USERS, array('userId'=>$user_id,'status'=>1));
        if(!$is_id_exist){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
            $this->response($response); 
        }
        $user_favourites = $this->Users_model->get_user_favourite_list($user_id, $limit, $offset, $check_status=true);
        $response = array('status' => SUCCESS, 'favouritesList'=>$user_favourites); //success msg
        $this->response($response);

    } //End function


     //get indivisual user list according to filters
    function getIndivisualSearchList_post(){

        //check for auth
        $this->check_service_auth();
        
        $offset = $this->get('offset'); $limit = $this->get('limit');
        if(empty($offset) || empty($limit)){
            $limit= $this->list_limit; $offset = 0;
        }
    
        $search = array();
        $set = array('speciality_id', 'job_title','availability', 'strength','value','location');
        foreach ($set as $key => $val) {
            $post= $this->post($val);
            if(!empty($post)){
                $search[$val] = $post;
            }
        }

        $search_list = $this->Users_model->get_indivisual_search_list($search, $limit, $offset);
        $response = array('status' => SUCCESS,'searchList'=>$search_list); //success msg
        $this->response($response);

    } //End function 

     //get business user list according to filteres
    function getBusinessSearchList_post(){

        //check for auth
        $this->check_service_auth();
        
        $offset = $this->get('offset'); $limit = $this->get('limit');
        if(empty($offset) || empty($limit)){
            $limit= $this->list_limit; $offset = 0;
        }
    
        $search = array();
        $set = array('speciality_id','rating', 'company','location');
        foreach ($set as $key => $val) {
            $post= $this->post($val);
            if(!empty($post)){
                $search[$val] = $post;
            }
        }

        $search_list = $this->Users_model->get_business_search_list($search, $limit, $offset);
        $response = array('status' => SUCCESS,'searchList'=>$search_list); //success msg
        $this->response($response);

    } //End function 


    //to get my profile details
    function getMyProfile_get(){

        //check for auth
        $this->check_service_auth();

        $user_id = $this->authData->userId;
        $user_type = $this->authData->userType;
        $where = array('um.user_id'=>$user_id);
        if($user_type == 'business'){

            $business_profile = $this->Users_model->get_my_business_profile($where);

            //get total review count by user_id
            $review_count    = $this->Users_model->get_count('COUNT(reviewId) as reviews_count',array('review_for'=>$user_id),REVIEWS);

            //get total favourite count by user_id
            $favourite_count = $this->Users_model->get_count('COUNT(favouriteId) as favourite_count',array('favourite_for'=>$user_id),FAVOURITES);
            
            //get total recommend count by user_id
            $recommend_count = $this->Users_model->get_count('COUNT(recommendId) as recommend_count',array('recommend_for'=>$user_id),RECOMMENDS);


            $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(126),'business_profile'=>$business_profile,'review_count'=>$review_count->reviews_count,'favourite_count'=>$favourite_count->favourite_count,'recommend_count'=>$recommend_count->recommend_count);
            $this->response($response);
        }

        $where_in = array('user_id'=>$user_id);
        $indivisual_profile   = $this->Users_model->get_indivisual_profile($where);
        $basic_info  = $this->Users_model->get_indivisual_basic_info($where);
        $experience  = $this->Users_model->get_user_experience($where_in);
        $resume      = $this->Users_model->get_user_resume($where_in);

        $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(126),'indivisual_profile'=>$indivisual_profile,'basic_info'=>$basic_info,'experience'=>$experience,'resume'=>$resume);
       
        $this->response($response); 
    } //End function


    //to get my profile details with review list for public view
    function getPublicProfile_get(){

        //check for auth
        $this->check_service_auth();

        $user_type = $this->authData->userType;
        $where = array('um.user_id'=>$this->authData->userId);
        if($user_type == 'business'){

            $public_profile = $this->Users_model->get_my_business_profile($where);
            $user_reviews = $this->Users_model->get_user_reviews_list($this->authData->userId, $limit, $offset, $check_status=true);
            $response = array('status'=>SUCCESS, 'message'=>ResponseMessages::getStatusCodeMessage(126),'public_profile'=>$public_profile,'review_list'=>$user_reviews);
            $this->response($response); 
        }

       
        $this->response($response); exit;
    } //End function

    //to send interview request to individual by user_id
    function interviewRequest_post(){

         //check for auth
        $this->check_service_auth();
        $current_user_id = $this->authData->userId; 

        $this->form_validation->set_rules('type', 'Type', 'trim|required',array('required'=>'Please select type.'));
        $this->form_validation->set_rules('interviewer_name','Interviewer name','trim|required');
        $this->form_validation->set_rules('location','Location','trim|required');
        $this->form_validation->set_rules('latitude','Latitude','trim|required');
        $this->form_validation->set_rules('longitude','Longitude','trim|required');
        $this->form_validation->set_rules('date','Date','trim|required');
        $this->form_validation->set_rules('time','Time','trim|required');
        $this->form_validation->set_rules('interview_for','Interview request','trim|required',array('required'=>'Please select user to interview_for'));

        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' =>preg_replace("/[\\n\\r]+/", " ",strip_tags(validation_errors())));
            $this->response($response); 
        }

        $is_id_exist = $this->common_model->is_data_exists(USERS, array('userId'=>$current_user_id,'status'=>1));
        if(!$is_id_exist){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
            $this->response($response); 
        }


        $set = array('type', 'interviewer_name', 'interviewer_name','location','latitude','longitude','date','time');
        foreach ($set as $key => $val) {
            $post= $this->post($val);
            if(!empty($post))
            $dataInsert[$val] = $post;
        }

        $is_id_exist = $this->common_model->is_data_exists(USERS, array('userId'=>$this->post('interview_for'),'status'=>1));
        if(!$is_id_exist){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(141)); //fail- User doesn't exist
            $this->response($response); 
        }
        
        $interview_data['interview_for'] = $this->post('interview_for');
        $interview_data['interview_by'] = $current_user_id;
        $interview_data['created_on'] = datetime();

        $interview_id =  $this->common_model->insertData(INTERVIEW, $interview_data);
        if(!$interview_id){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            $this->response($response); 
        }

        $dataInsert['created_on'] = datetime();
        $dataInsert['interview_id'] = $interview_id;
        $req_id = $this->common_model->insertData(INTERVIEW_REQUEST, $dataInsert);
        if(!$req_id){

            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            $this->response($response); 
        }

        $progress_data['request_id'] = $req_id;

        $progress_id = $this->common_model->insertData(REQUEST_PROGRESS, $progress_data);
        if(!$progress_id){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            $this->response($response); 
        }

        $request_data = $this->Users_model->get_request_data(array('requestId'=>$req_id));
        $response = array('status'=>SUCCESS,'message'=>ResponseMessages::getStatusCodeMessage(144),'request_data'=>$request_data); //successfully inserted
        $this->response($response); 

    } //End function

    //to update request status by request_id
    function updateRequestStatus_post(){

        //check for auth
        $this->check_service_auth();
        
        $this->form_validation->set_rules('request_id','request_id','trim|required');
        $this->form_validation->set_rules('status','status','trim|required');

        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' =>preg_replace("/[\\n\\r]+/", " ",strip_tags(validation_errors())));
            $this->response($response);
        }

        $is_exists = $this->common_model->is_data_exists(INTERVIEW_REQUEST, array('requestId'=>$this->post('request_id')));
        if(!$is_exists){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            $this->response($response);
        }

        $req_data['status']  = $this->post('status');

        $request_progress = $this->common_model->updateFields(REQUEST_PROGRESS, $req_data, array('request_id'=>$this->post('request_id')));

        if(!$request_progress){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            $this->response($response);
        }

        $response = array('status'=>SUCCESS,'message'=>ResponseMessages::getStatusCodeMessage(145)); //successfully updated
        $this->response($response);

    } //End function

    //to delete interview request, when jobseeker decline the request
    function deleteRequest_post(){

        //check for auth
        $this->check_service_auth();
        
        $this->form_validation->set_rules('request_id','request_id','trim|required');

        if($this->form_validation->run() == FALSE){
            $response = array('status' => FAIL, 'message' =>preg_replace("/[\\n\\r]+/", " ",strip_tags(validation_errors())));
            $this->response($response);
        }


        $is_exists = $this->common_model->is_data_exists(INTERVIEW_REQUEST, array('requestId'=>$this->post('request_id')));
        if(!$is_exists){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(147)); //fail- request id doesn't exist
            $this->response($response);
        }

        $is_delete = $this->common_model->deleteData(INTERVIEW_REQUEST,array('requestId'=>$this->post('request_id')));
        if(!$is_delete){
            $response = array('status'=>FAIL,'message'=>ResponseMessages::getStatusCodeMessage(118)); //fail- something went wrong
            $this->response($response);
        }
        $response = array('status'=>SUCCESS,'message'=>ResponseMessages::getStatusCodeMessage(146)); //successfully deleted
        $this->response($response);
    } //End function




}//End Class 


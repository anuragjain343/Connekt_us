<?php
class Users_model extends CI_Model {

	function getDropdown_data($where,$offset,$limit){
		
		$res['value_list']        = $this->db->select('valueId,valueName')->order_by('valueName', 'ASC')->get(VALUE)->result_array();
        $res['strenght_list']   = $this->db->select('strengthId,strengthName')->order_by('strengthName', 'ASC')->get(STRENGTHS)->result_array();
        $res['speciality_list'] = $this->db->select('specializationId,specializationName')->order_by('specializationName', 'ASC')->get_where(SPECIALIZATIONS,$where)->result_array();
         $res['opposite_speciality_list'] = $this->db->select('specializationId,specializationName')->order_by('specializationName', 'ASC')->get_where(SPECIALIZATIONS,array('userType !='=>$this->authData->userType))->result_array();
        $res['job_title']       = $this->db->select('jobTitleId,jobTitleName')->order_by('jobTitleName', 'ASC')->get_where(JOB_TITLES,$where)->result_array();
        $res['availability_list'] = get_availability();
        $res['company_list'] = $this->getComapny($limit, $offset);
        
 		return $res;   	
	}


	   //get all details related to business profile
    function get_business_list($where){
     
       	$defaultImg = base_url().DEFAULT_USER;
 		$logo = base_url().COMPANY_LOGO;
        $default_logo = base_url().COMPANY_LOGO_DEFAULT;
 		$user_image = base_url().USER_THUMB;

        $this->db->select('um.address,um.latitude,um.longitude,um.bio,

        	(case 
                    when( um.company_logo = "" OR um.company_logo IS NULL) 
                    THEN "'.$default_logo.'"
                    ELSE
                    concat("'.$logo.'",um.company_logo) 
                   END ) as company_logo

        	,aos.specializationName,job.jobTitleName,usr.fullName,usr.email,usr.profileImage,usr.businessName,
        	(case 
                    when( usr.profileImage = "" OR usr.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",usr.profileImage) 
                   END ) as profileImage

        	');
        $this->db->from(USER_META .' as um');
       
        $this->db->join(USER_SPECIALIZATION_MAPPING. ' as usm', "usm.user_id = um.user_id","left"); //to get area of specialization detail

         $this->db->join(SPECIALIZATIONS. ' as aos', "usm.specialization_id = aos.specializationId","left"); //to get area of specialization 

        $this->db->join(JOB_TITLES. ' as job', "um.jobTitle_id = job.jobTitleId","left"); //to get job titles
        
        $this->db->join(USERS. ' as usr', "um.user_id = usr.userId","left"); //to get user details 

        if(!empty($where))
            $this->db->where($where);
	        $result = $this->db->get();
	        $res = $result->result_array(); 
       	 	return $res;
    }
    

    function get_business_user($where){

        $default_logo = base_url().COMPANY_LOGO_DEFAULT;
        $logo = base_url().COMPANY_LOGO;

        $this->db->select('um.address,um.latitude,um.longitude,um.bio,

            (case 
                    when( um.company_logo = "" OR um.company_logo IS NULL) 
                    THEN "'.$default_logo.'"
                    ELSE
                    concat("'.$logo.'",um.company_logo) 
                   END ) as company_logo

            ,aos.specializationName,job.jobTitleName

            ');
        $this->db->from(USER_META .' as um');
       
        $this->db->join(USER_SPECIALIZATION_MAPPING. ' as usm', "usm.user_id = um.user_id","left"); //to get area of specialization detail

        $this->db->join(SPECIALIZATIONS. ' as aos', "usm.specialization_id = aos.specializationId","left"); //to get area of specialization 

        $this->db->join(JOB_TITLES. ' as job', "um.jobTitle_id = job.jobTitleId","left"); //to get job titles
        

        if(!empty($where))
            $this->db->where($where);
            $result = $this->db->get();
            $res = $result->result_array(); 
            return $res;

    } //End function

    function get_indivisual_basic_info($where){

        $this->db->select('um.address,um.latitude,um.longitude,um.bio,aos.specializationName,
            GROUP_CONCAT(DISTINCT val.valueName) as value,GROUP_CONCAT(DISTINCT str.strengthName) as strength');
        $this->db->from(USER_META .' as um');
       
        $this->db->join(USER_SPECIALIZATION_MAPPING. ' as usm', "usm.user_id = um.user_id","left"); //to get area of specialization detail

        $this->db->join(SPECIALIZATIONS. ' as aos', "usm.specialization_id = aos.specializationId","left"); //to get area of specialization 

        $this->db->join(USER_VALUE_MAPPING. ' as uv', "uv.user_id = um.user_id","left");
        $this->db->join(VALUE. ' as val', "uv.value_id = val.valueId","left");


        $this->db->join(USER_STRENGTH_MAPPING. ' as ustr',"ustr.user_id = um.user_id" ,"left");
        

        $this->db->join(STRENGTHS. ' as str', "ustr.strength_id = str.strengthId","left");

        if(!empty($where))
            $this->db->where($where);
            $result = $this->db->get();  
            $res = $result->row(); 
            return $res;
    } //End function


    function get_user_experience($where){
         
        $exp = array();
        $this->db->select('exp.*,job.jobTitleName,aos.specializationName as next_speciality');
        $this->db->from(USER_EXPERIENCE .' as exp');
        $this->db->join(JOB_TITLES. ' as job', "exp.current_job_title = job.jobTitleId","left"); //to get job titles
        $this->db->join(SPECIALIZATIONS. ' as aos', "exp.next_speciality = aos.specializationId","left");//to get area of specialization  
        $this->db->where($where);
        $a =  $this->db->get()->row(); 

        if(empty($a))
            return $exp;

        $exp['current_role'] = array(
               'current_job_title'=> $a->jobTitleName,
               'current_company'=> $a->current_company,
               'current_start_date'=>$a->current_start_date,
               'current_finish_date'=> $a->current_finish_date,
               'current_description'=>$a->current_description
            );

        $exp['previous_role'] = array(
               'previous_experience'=> json_decode($a->previous_role)
            );


        $exp['next_role'] = array(
               'next_availability'=> $a->next_availability,
               'next_speciality'=> $a->next_speciality,
               'next_location'=>$a->next_location
            );

        return $exp;
    } //End function

    //get user resume and CV by user ID
    function get_user_resume($where){
       
        $resume = base_url().USER_RESUME;
        $cv = base_url().USER_CV;

        $this->db->select('
            (case
                when(user_resume = "")
                THEN ""
                ELSE CONCAT ("'.$resume.'",user_resume) 
                END ) as user_resume ,

                (case
                when(user_cv = "")
                THEN ""
                ELSE CONCAT("'.$cv.'",user_cv) 
                END ) as user_cv');

        $res = $this->db->where($where)->get(USER_META)->row();
        return $res;
    }


    //get last inserted user reviews by user ID
    function get_user_reviews($user_id, $limit, $offset=0){
        
        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;
        $where['r.review_for'] =  $user_id;
 
        $this->db->select('r.*, u.fullName,
                (case 
                    when( u.profileImage = "" OR u.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",u.profileImage) 
                   END ) as profileImage');
        $this->db->from(REVIEWS .' as r'); //reviews
        $this->db->join(USERS. ' as u', "r.review_by = u.userId"); //to get user meta details
        $this->db->where($where);
        $this->db->limit($limit, $offset);
        $this->db->order_by('r.reviewId', 'DESC');
        $result = $this->db->get();
        $res = $result->result(); 
        if($res[0]->is_anonymous == 1){
            $res[0]->fullName = 'Anonymous';
            $res[0]->profileImage = $defaultImg;
        }
        
        return $res;
    } //End function


    //get user reviews by user ID
    function get_user_reviews_list($user_id, $limit, $offset=0, $check_status=true){
        
        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;
        $where['r.review_for'] =  $user_id;
        $where['u.status'] =  1;
        
        if(!$check_status)
            $where['u.status'] = 0;
        
        $this->db->select('r.*, u.fullName,NOW() as today_datetime,(case 
                    when( u.profileImage = "" OR u.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"

                    when( r.is_anonymous = 1) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",u.profileImage) 
                   END ) as profileImage,

                   (case 
                    when( r.is_anonymous = 1) 
                    THEN "Anonymous"
                    ELSE
                    u.fullName
                   END ) as fullName
                   ');
        $this->db->from(REVIEWS .' as r'); //reviews
        $this->db->join(USERS. ' as u', "r.review_by = u.userId"); //to get user meta details
        $this->db->where($where);
        $this->db->limit($limit, $offset);
        $this->db->order_by('r.reviewId', 'DESC');
        $result = $this->db->get();
        $res = $result->result();
        return $res;
    } // End function


    //get user recommend by user ID
    function get_user_recommend_list($user_id, $limit, $offset=0, $check_status=true){


        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;
        $where['rec.recommend_for'] =  $user_id;
        $where['u.status'] =  1;
        
        if(!$check_status)
            $where['u.status'] = 0;
        
        $this->db->select('rec.*, u.fullName,NOW() as today_datetime,(case 
                    when( u.profileImage = "" OR u.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",u.profileImage) 
                   END ) as profileImage
                  
                   ');
        $this->db->from(RECOMMENDS .' as rec'); //recommend
        $this->db->join(USERS. ' as u', "rec.recommend_by = u.userId"); //to get user meta details
        $this->db->where($where);
        $this->db->limit($limit, $offset);
        $this->db->order_by('rec.recommendId', 'DESC');
        $result = $this->db->get();
        $res = $result->result();
        return $res;

    }

    //get user favourites by user ID
    function get_user_favourite_list($user_id, $limit, $offset=0, $check_status=true){

        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;
        $where['fav.favourite_for'] =  $user_id;
        $where['u.status'] =  1;
        
        if(!$check_status)
            $where['u.status'] = 0;
     
        $this->db->select('fav.*, u.fullName,u.businessName,NOW() as today_datetime,(case 
                    when( u.profileImage = "" OR u.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",u.profileImage) 
                   END ) as profileImage
                  
                   ');
        $this->db->from(FAVOURITES .' as fav'); //favourites
        $this->db->join(USERS. ' as u', "fav.favourite_by = u.userId"); //to get user meta details
        $this->db->where($where);
        $this->db->limit($limit, $offset);
        $this->db->order_by('fav.favouriteId', 'DESC');
        $result = $this->db->get();
        $res = $result->result();
        return $res;

    } 

     //get indivisual user list according to filteres
    function get_indivisual_search_list($search, $limit, $offset){

      
        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;

        $this->db->select('usr.fullName,COALESCE(aos.specializationName,"") as specializationName,COALESCE(um.address,"") as address,
            COALESCE(um.latitude, "") as latitude,COALESCE(um.longitude, "") as longitude,
            (case 
                    when( usr.profileImage = "" OR usr.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",usr.profileImage) 
                   END ) as profileImage

            ');
        $this->db->from(USERS .' as usr');
        $this->db->join(USER_META .' as um',"um.user_id = usr.userId","left"); //to get user's meta info
       
        $this->db->join(USER_SPECIALIZATION_MAPPING. ' as usm', "usm.user_id = usr.userId","left"); //to get area of specialization detail

        $this->db->join(SPECIALIZATIONS. ' as aos', "usm.specialization_id = aos.specializationId","left");//to get area of specialization  
        $this->db->join(USER_EXPERIENCE. ' as exp', "exp.user_id = usr.userId","left" );
        $this->db->join(JOB_TITLES. ' as job', "exp.current_job_title = job.jobTitleId","left"); //to get job titles
        $this->db->join(USER_STRENGTH_MAPPING. ' as ustr',"ustr.user_id = um.user_id" ,"left");
        $this->db->join(STRENGTHS. ' as str', "ustr.strength_id = str.strengthId","left");

        $this->db->join(USER_VALUE_MAPPING. ' as uv', "uv.user_id = um.user_id","left");
        $this->db->join(VALUE. ' as val', "uv.value_id = val.valueId","left");

        
        !empty($search['speciality_id']) ? $this->db->where(array('usm.specialization_id'=>$search['speciality_id'])) : "";
        !empty($search['job_title']) ? $this->db->where(array('exp.current_job_title'=>$search['job_title'])) : ""; 
        !empty($search['strength']) ? $this->db->where(array('ustr.strength_id'=>$search['strength'])) : ""; 
        !empty($search['availability']) ? $this->db->where(array('exp.next_availability'=>$search['availability'])) : ""; 
        !empty($search['value']) ? $this->db->where(array('uv.value_id'=>$search['value'])) : ""; 

        if(!empty($search['location'])){
            $this->db->where(array('um.address'=>$search['location']));
            $this->db->or_like('um.address', $search['location']);
        } 

        $this->db->where(array('usr.status'=>1,'usr.userType'=>'individual'));
        $this->db->limit($limit, $offset);
        $this->db->group_by('usr.userId');
        $this->db->order_by('usr.userId', 'DESC');
        $result = $this->db->get(); 
        $res    = $result->result(); 
        return $res;
    }
    
    //to business user list according to filters
    function get_business_search_list($search, $limit, $offset){

      
        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;
        $logo = base_url().COMPANY_LOGO;
        $default_logo = base_url().COMPANY_LOGO_DEFAULT;

        $this->db->select('usr.fullName,usr.businessName,COALESCE(aos.specializationName,"") as specializationName,COALESCE(um.address,"") as address,
            COALESCE(um.latitude, "") as latitude,COALESCE(um.longitude, "") as longitude,COALESCE(AVG(r.rating), "") as rating,
            (case 
                    when( usr.profileImage = "" OR usr.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",usr.profileImage) 
                   END ) as profileImage,

                   (case 
                    when( um.company_logo = "" OR um.company_logo IS NULL) 
                    THEN "'.$default_logo.'"
                    ELSE
                    concat("'.$logo.'",um.company_logo) 
                   END ) as company_logo


            ');
        $this->db->from(USERS .' as usr');
        $this->db->join(USER_META .' as um',"um.user_id = usr.userId","left"); //to get user's meta info
       
        $this->db->join(USER_SPECIALIZATION_MAPPING. ' as usm', "usm.user_id = usr.userId","left"); //to get area of specialization detail

        $this->db->join(SPECIALIZATIONS. ' as aos', "usm.specialization_id = aos.specializationId","left");//to get area of specialization  

        $this->db->join(REVIEWS .' as r',"r.review_for = usr.userId","left"); //reviews
        
        !empty($search['speciality_id']) ? $this->db->where(array('usm.specialization_id'=>$search['speciality_id'])) : "";
       

        if(!empty($search['rating'])){
            $this->db->where(array('r.rating'=>$search['rating']));
            $this->db->group_by('r.review_for');
        }
        
        if(!empty($search['company'])){
            $this->db->where(array('usr.businessName'=>$search['company']));
            $this->db->or_like('usr.businessName', $search['company']);
        }

        if(!empty($search['location'])){
            $this->db->where(array('um.address'=>$search['location']));
            $this->db->or_like('um.address', $search['location']);
        }

        $this->db->where(array('usr.status'=>1,'usr.userType'=>'business'));
        $this->db->limit($limit, $offset);
        $this->db->group_by('usr.userId');
        $this->db->order_by('usr.userId', 'DESC');
        $result = $this->db->get(); 
        $res = $result->result(); 
        return $res;
    }


    //to get user's business profile detail
    function get_my_business_profile($where){

        $default_logo = base_url().COMPANY_LOGO_DEFAULT;
        $logo = base_url().COMPANY_LOGO;
        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;


        $this->db->select('u.fullName,job.jobTitleName,um.address,um.latitude,um.longitude,um.bio,
            COALESCE(aos.specializationName, "") as specializationName,COALESCE(AVG(r.rating), "") as rating,
            (case 
                    when( um.company_logo = "" OR um.company_logo IS NULL) 
                    THEN "'.$default_logo.'"
                    ELSE
                    concat("'.$logo.'",um.company_logo) 
                   END ) as company_logo,
            (case 
                    when( u.profileImage = "" OR u.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",u.profileImage) 
                   END ) as profileImage,

            ');

        $this->db->from(USER_META .' as um');
        $this->db->join(USERS. ' as u', "um.user_id = u.userId"); //to get user meta details
       
        $this->db->join(USER_SPECIALIZATION_MAPPING. ' as usm', "usm.user_id = um.user_id","left"); //to get area of specialization detail

        $this->db->join(SPECIALIZATIONS. ' as aos', "usm.specialization_id = aos.specializationId","left"); //to get area of specialization 

        $this->db->join(JOB_TITLES. ' as job', "um.jobTitle_id = job.jobTitleId","left"); //to get job titles
        $this->db->join(REVIEWS. ' as r',"r.review_for = um.user_id","left");
      
        $this->db->where($where);
        $result = $this->db->get();
        $res = $result->result(); 
        return $res;

    }

    //to get count 
    function get_count($select,$where,$table){

        return $this->db->select($select)->get_where($table,$where)->row();
    }

    //to get indivisual information by user_id 
    function get_indivisual_profile($where){


        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;

        $this->db->select('usr.fullName,aos.specializationName,um.address,job.jobTitleName
            ,aos.specializationName,um.latitude,um.longitude,
            (case 
                    when( usr.profileImage = "" OR usr.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",usr.profileImage) 
                   END ) as profileImage
            ');
        $this->db->from(USERS .' as usr');
        $this->db->join(USER_META .' as um',"um.user_id = usr.userId","left"); //to get user's meta info
       
        $this->db->join(USER_SPECIALIZATION_MAPPING. ' as usm', "usm.user_id = usr.userId","left"); //to get area of specialization detail

        $this->db->join(SPECIALIZATIONS. ' as aos', "usm.specialization_id = aos.specializationId","left");//to get area of specialization  
        $this->db->join(USER_EXPERIENCE. ' as exp', "exp.user_id = usr.userId","left" );
        $this->db->join(JOB_TITLES. ' as job', "exp.current_job_title = job.jobTitleId","left"); //to get job titles
        $this->db->join(USER_STRENGTH_MAPPING. ' as ustr',"ustr.user_id = um.user_id" ,"left");
        $this->db->join(STRENGTHS. ' as str', "ustr.strength_id = str.strengthId","left");

        $this->db->join(USER_VALUE_MAPPING. ' as uv', "uv.user_id = um.user_id","left");
        $this->db->join(VALUE. ' as val', "uv.value_id = val.valueId","left");

        $this->db->where('usr.status',1);
        $this->db->where($where);
        $this->db->group_by('usr.userId');
        $this->db->order_by('usr.userId', 'DESC');
        $result = $this->db->get(); 
        $res    = $result->result(); 
        return $res;

    }

    //to get interview request data by request_id
    function get_request_data($where){

        $defaultImg = base_url().DEFAULT_USER;
        $user_image = base_url().USER_THUMB;
        $this->db->select('usr.fullName as interview_for ,ireq.type,ireq.interviewer_name,ireq.location,ireq.latitude,ireq.longitude,ireq.date, ireq.time,req.status,
            (case 
                    when( usr.profileImage = "" OR usr.profileImage IS NULL) 
                    THEN "'.$defaultImg.'"
                    ELSE
                    concat("'.$user_image.'",usr.profileImage) 
                   END ) as profileImage
            ');
        $this->db->from(USERS .' as usr');

        $this->db->join(INTERVIEW .' as intr',"intr.interview_for = usr.userId","left");
        $this->db->join(INTERVIEW_REQUEST .' as ireq',"ireq.interview_id = intr.interviewId","left");
        $this->db->join(REQUEST_PROGRESS .' as req',"req.request_id = ireq.requestId","left");
        $this->db->where('usr.status',1);
        $this->db->where($where);
        $result = $this->db->get(); 
        $res    = $result->result(); 
        return $res;

    }


       //to get company
    function getComapny($limit, $offset){

        $this->db->select('DISTINCT (businessName) as company_name');
        $this->db->from(USERS .' as usr'); 
        $this->db->where('userType','business');
        $this->db->limit($limit, $offset);
        $this->db->order_by('usr.userId', 'DESC');
        $result = $this->db->get();
        $res = $result->result();
        return $res;
    }
   
        
}//ENd Class
?>
